#include<iostream>
#include<vector>
#include<future>

#include"Operations.h"
#include"ThreadPool.h"

using namespace std;

void startNThreadsAdd(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]) {
	std::vector<future<void>> futures;
	for (int i = 0; i < SIZE; i++) {
		futures.push_back(async( addNThread,a,b,result,i ));
	}
	for (unsigned int i = 0; i < futures.size(); i++)
	{
		futures[i].wait();
	}
	
}
void startNThreadsMultiply(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]) {
	
	std::vector<future<void>> futures;
	for (int i = 0; i < SIZE; i++) {
		futures.push_back(async(multiplyNThread, a, b, result, i));
	}
	for (unsigned int i = 0; i < futures.size(); i++)
	{
		futures[i].wait();
	}
}

void startElemThreadsAdd(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]) {
	
	std::vector<future<void>> futures;
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++)
			futures.push_back(async(addElemThread, a, b, result, i,j));
	}
	for (unsigned int i = 0; i < futures.size(); i++)
	{
		futures[i].wait();
	}
}

void startElemThreadsMultiply(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]) {
	std::vector<future<void>> futures;
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++)
			futures.push_back(async(multiplyElemThread, a, b, result, i,j));
	}
	for (unsigned int i = 0; i < futures.size(); i++)
	{
		futures[i].wait();
	}
}

void menu() {
	cout << "0.Exit\n";
	cout << "1.Add one thread\n";
	cout << "2. Add N threads\n";
	cout << "3. Add N*N threads\n";
	cout << "4. Mult one threads\n";
	cout << "5. Mult N threads\n";
	cout << "6. Mult N*N threads\n";
	cout << "Enter command:";
}

int main() {

	std::chrono::steady_clock::time_point begin, end;
	int a[SIZE][SIZE], b[SIZE][SIZE], result[SIZE][SIZE];
	for (int i = 0; i < SIZE; i++)
		for (int j = 0; j < SIZE; j++) {
			a[i][j] = i + j;
			b[i][j] = SIZE - i + j;
		}
	int command;
	while (true) {
		menu();
		cin >> command;
		switch (command) {
		case 0:
			return 0;
		case 1:
			for (int i = 0; i < SIZE; i++)
				for (int j = 0; j < SIZE; j++) {
					a[i][j] = i + j;
					b[i][j] = SIZE - i + j;
				}
			begin = chrono::high_resolution_clock::now();
			multiplyOneThread(a, b, result);
			end = chrono::high_resolution_clock::now();
			cout << std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << "ms\n";
			//printMatrix(result);
			break;
		case 2:
			for (int i = 0; i < SIZE; i++)
				for (int j = 0; j < SIZE; j++) {
					a[i][j] = i + j;
					b[i][j] = SIZE - i + j;
				}
			begin = chrono::high_resolution_clock::now();
			startNThreadsMultiply(a, b, result);
			end = chrono::high_resolution_clock::now();
			cout << std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << "ms\n";
			//printMatrix(result);
			break;
		case 3:
			for (int i = 0; i < SIZE; i++)
				for (int j = 0; j < SIZE; j++) {
					a[i][j] = i + j;
					b[i][j] = SIZE - i + j;
				}
			begin = chrono::high_resolution_clock::now();
			startElemThreadsMultiply(a, b, result);
			end = chrono::high_resolution_clock::now();
			cout << std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << "ms\n";
			//printMatrix(result);
			break;
		case 4:
			for (int i = 0; i < SIZE; i++)
				for (int j = 0; j < SIZE; j++) {
					a[i][j] = i + j;
					b[i][j] = SIZE - i + j;
				}
			begin = chrono::high_resolution_clock::now();
			addOneThread(a, b, result);
			end = chrono::high_resolution_clock::now();
			cout << std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << "ms\n";
			//printMatrix(result);
			break;
		case 5:
			for (int i = 0; i < SIZE; i++)
				for (int j = 0; j < SIZE; j++) {
					a[i][j] = i + j;
					b[i][j] = SIZE - i + j;
				}
			begin = chrono::high_resolution_clock::now();
			startNThreadsAdd(a, b, result);
			end = chrono::high_resolution_clock::now();
			cout << std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << "ms\n";
			//printMatrix(result);
			break;
		case 6:
			for (int i = 0; i < SIZE; i++)
				for (int j = 0; j < SIZE; j++) {
					a[i][j] = i + j;
					b[i][j] = SIZE - i + j;
				}
			begin = chrono::high_resolution_clock::now();
			startElemThreadsMultiply(a, b, result);
			end = chrono::high_resolution_clock::now();
			cout << std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << "ms\n";
			//printMatrix(result);
			break;

		}
	}

	return 0;
}