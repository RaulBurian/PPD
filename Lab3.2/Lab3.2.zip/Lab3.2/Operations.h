
#define SIZE 50

void printMatrix(int a[SIZE][SIZE]);
void multiplyOneThread(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]);
void addOneThread(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]);
void multiplyNThread(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE], int lineNr);
void addNThread(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE], int lineNr);
void addElemThread(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE], int lineNr, int colNr);
void multiplyElemThread(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE], int lineNr, int colNr);